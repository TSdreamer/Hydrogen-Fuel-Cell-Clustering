# Application-from-Haotian

1. This code is for Prof.Catalina Spataru and Haotian Ma to use only

2. The first folder is the database construction for the water electrolysis industry. The proton exchange membrane water electrolysis database has already contained more than 100 data points. Each document should contain more than 300 data points for future use.(Energy Performance+Carbon Reduction).The data will be continued to be expanded in stage 1-first year.

3. The second folder is the code for machine learning-based clustering algorithms which contains several algorithms(K-Means， K-Medoids，CLARANS， Canopy and etc). It will be expanded in stage 1-first year.

4. The third folder is for the evaluation and comparison of different algorithms should be used.The classical internal evaluation indicators like Dunn Indicators,DB Indicators,XB Indicators,XB indicators,SD Indicators should be used,while the external indicators contains F-measure indicators,NMI Indicators,RI Indicators.

5. The last folder is for the industry mining and policy regulation,It will be finally construed at the stage 3.
